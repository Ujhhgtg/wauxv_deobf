
void onHandleMsg(Object msgInfoBean) {
    if (!msgInfoBean.isSend()) return;
    if (msgInfoBean.isText()) {
        String content = msgInfoBean.getContent();
        String talker = msgInfoBean.getTalker();
        if (content.startsWith("/改步数 ")) {
            String[] split = content.split(" ");
            if (split.length == 2) {
                long step = Long.parseLong(split[1]);
                uploadDeviceStep(step);
                sendText(talker, "已修改步数为自定义" + step);
            }
        }
    }
}

boolean onClickSendBtn(String text) {
    if (text.equals("测试")) {
        sendText(getTargetTalker(), "测试成功");
        return true;
    }
    return false;
}
